import React, { useState } from 'react';
import { Search, Star, TrendingUp, Film } from 'lucide-react';

// Mock data - In a real app, this would come from an API
const movies = [
  {
    id: 1,
    title: "Dune: Part Two",
    rating: 8.8,
    image: "https://images.unsplash.com/photo-1534972195531-d756b9bfa9f2?auto=format&fit=crop&q=80&w=800",
    description: "Paul Atreides unites with Chani and the Fremen while seeking revenge against the conspirators who destroyed his family.",
    trending: true
  },
  {
    id: 2,
    title: "Poor Things",
    rating: 8.4,
    image: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80&w=800",
    description: "The incredible tale about the fantastical evolution of Bella Baxter, a young woman brought back to life by the brilliant and unorthodox scientist Dr. Godwin Baxter.",
    trending: true
  },
  {
    id: 3,
    title: "Oppenheimer",
    rating: 8.9,
    image: "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?auto=format&fit=crop&q=80&w=800",
    description: "The story of American scientist J. Robert Oppenheimer and his role in the development of the atomic bomb.",
    trending: true
  }
];

function App() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMovie, setSelectedMovie] = useState(null);

  const filteredMovies = movies.filter(movie =>
    movie.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100">
      {/* Header */}
      <header className="bg-gray-800 shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Film className="w-8 h-8 text-purple-500" />
              <h1 className="text-2xl font-bold">MovieCritic</h1>
            </div>
            <div className="relative">
              <input
                type="text"
                placeholder="Search movies..."
                className="w-64 px-4 py-2 rounded-lg bg-gray-700 focus:outline-none focus:ring-2 focus:ring-purple-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <Search className="absolute right-3 top-2.5 text-gray-400 w-5 h-5" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Trending Section */}
        <section className="mb-12">
          <div className="flex items-center space-x-2 mb-6">
            <TrendingUp className="w-6 h-6 text-purple-500" />
            <h2 className="text-xl font-semibold">Trending Movies</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredMovies.map(movie => (
              <div
                key={movie.id}
                className="bg-gray-800 rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300"
                onClick={() => setSelectedMovie(movie)}
              >
                <img
                  src={movie.image}
                  alt={movie.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-lg font-semibold">{movie.title}</h3>
                    <div className="flex items-center space-x-1">
                      <Star className="w-4 h-4 text-yellow-500 fill-current" />
                      <span>{movie.rating}</span>
                    </div>
                  </div>
                  <p className="text-gray-400 text-sm line-clamp-2">
                    {movie.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Movie Details Modal */}
        {selectedMovie && (
          <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4">
            <div className="bg-gray-800 rounded-lg max-w-2xl w-full">
              <div className="relative">
                <img
                  src={selectedMovie.image}
                  alt={selectedMovie.title}
                  className="w-full h-64 object-cover rounded-t-lg"
                />
                <button
                  className="absolute top-4 right-4 bg-gray-900 bg-opacity-50 rounded-full p-2"
                  onClick={() => setSelectedMovie(null)}
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-2xl font-bold">{selectedMovie.title}</h2>
                  <div className="flex items-center space-x-2">
                    <Star className="w-6 h-6 text-yellow-500 fill-current" />
                    <span className="text-xl">{selectedMovie.rating}</span>
                  </div>
                </div>
                <p className="text-gray-300">{selectedMovie.description}</p>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 mt-12">
        <div className="container mx-auto px-4 py-6">
          <p className="text-center text-gray-400">© 2024 MovieCritic. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;